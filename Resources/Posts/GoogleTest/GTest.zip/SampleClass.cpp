/*
 * SampleClass.cpp
 *
 *  Created on: May 3, 2017
 *      Author: huyaoyu <huyaoyu@sjtu.edu.cn>
 */

#include "SampleClass.hpp"

using namespace GT;

SampleClass::SampleClass(void)
{

}

SampleClass::~SampleClass(void)
{

}

int SampleClass::check_positive(int v)
{
	return v > 0 ? 1 : 0;
}

int SampleClass::check_negative(int v)
{
	return v < 0 ? 1 : 0;
}

