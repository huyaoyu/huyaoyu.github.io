/*
 * TestBase.hpp
 *
 *  Created on: May 3, 2017
 *      Author: huyaoyu <huyaoyu@sjtu.edu.cn>
 */

#ifndef TESTBASE_HPP_
#define TESTBASE_HPP_


#include <gtest/gtest.h>

#include <fstream>
#include <string>
#include <math.h>

#include "SampleClass.hpp"

namespace GT
{

class SampleClass;

class TestBase : public ::testing::Test
{
public:
	TestBase(void);
	virtual ~TestBase(void);
	static void SetUpTestCase();
	static void TearDownTestCase();
	virtual void SetUp(void);
	virtual void TearDown(void);


public:
	static int mArgc;
	static char** mArgs;

	static SampleClass* pSC;
};


}


#endif /* TESTBASE_HPP_ */
