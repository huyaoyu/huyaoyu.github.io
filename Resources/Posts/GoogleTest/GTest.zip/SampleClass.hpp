/*
 * SampleClass.hpp
 *
 *  Created on: May 3, 2017
 *      Author: huyaoyu <huyaoyu@sjtu.edu.cn>
 */

#ifndef SAMPLECLASS_HPP_
#define SAMPLECLASS_HPP_

#include "TestBase.hpp"

namespace GT
{

class SampleClass
{
public:
	SampleClass(void);
	~SampleClass(void);

public:
	int check_positive(int v);

private:
	int check_negative(int v);

public:
	FRIEND_TEST(TestBase, test_check_positive);
	FRIEND_TEST(TestBase, test_check_negative);
	FRIEND_TEST(TestBase, test_check_negative_fail);
};

}


#endif /* SAMPLECLASS_HPP_ */
