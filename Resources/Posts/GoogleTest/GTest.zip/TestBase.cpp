/*
 * TestBase.cpp
 *
 *  Created on: May 3, 2017
 *      Author: huyaoyu <huyaoyu@sjtu.edu.cn>
 */

#include "TestBase.hpp"


namespace GT
{

TEST_F(TestBase, test_check_positive)
{
	int v = 1;
	int res = 0;
	int res_expected = 1;

	res = pSC->check_positive(v);

	ASSERT_EQ( res, res_expected );
}

TEST_F(TestBase, test_check_negative)
{
	int v = -1;
	int res = 0;
	int res_expected = 1;

	res = pSC->check_negative(v);

	ASSERT_EQ( res, res_expected );
}

}


using namespace GT;

int TestBase::mArgc = 0;
char** TestBase::mArgs = NULL;

SampleClass* TestBase::pSC = NULL;

TestBase::TestBase(void)
{

}

TestBase::~TestBase(void)
{

}

void TestBase::SetUpTestCase()
{
	std::cout << "Set up test cases." << std::endl;

	if ( pSC != NULL )
	{
		delete pSC;
	}

	pSC = new SampleClass;
}

void TestBase::TearDownTestCase()
{
	std::cout << "Tear down test cases." << std::endl;

	delete pSC; pSC = NULL;
}

void TestBase::SetUp(void)
{

}

void TestBase::TearDown(void)
{

}


