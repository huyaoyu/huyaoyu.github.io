/*
 * main.cpp
 *
 *  Created on: May 3, 2017
 *      Author: huyaoyu <huyaoyu@sjtu.edu.cn>
 */

#include "TestBase.hpp"
#include "SampleClass.hpp"

int main(int argc,char* argv[])
{
	int testRes = 0;

	GT::TestBase::mArgc = argc;
	GT::TestBase::mArgs = argv;

	::testing::InitGoogleTest(&argc,argv);

	testRes = RUN_ALL_TESTS();

	return testRes;
}


