/*
 * SeparateTestFile.cpp
 *
 *  Created on: May 4, 2017
 *      Author: huyaoyu <huyaoyu@sjtu.edu.cn>
 */

#include "TestBase.hpp"

namespace GT
{

TEST_F(TestBase, test_check_negative_fail)
{
	int v = -1;
	int res = 0;
	int res_expected = 0;

	res = pSC->check_negative(v);

	ASSERT_EQ( res, res_expected );
}

}


